from django.contrib import admin
from crudapp.models import *
# Register your models here.

admin.site.register(Author)
admin.site.register(Book)
admin.site.register(Country)