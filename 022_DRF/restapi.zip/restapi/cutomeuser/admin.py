from django.contrib import admin
from cutomeuser.models import *
# Register your models here.
admin.site.register(CustomeUser)
admin.site.register(RoleManager)